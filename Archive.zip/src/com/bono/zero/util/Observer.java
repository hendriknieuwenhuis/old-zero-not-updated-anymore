package com.bono.zero.util;

import com.bono.zero.util.Observable;

public interface Observer {
	
	void update(String update, Object arg);

}
