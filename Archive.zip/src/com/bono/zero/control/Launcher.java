package com.bono.zero.control;

import com.bono.zero.model.*;
import com.bono.zero.view.*;
import com.bono.zero.view.SplashScreen;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

/**
 * Created by hennihardliver on 23/05/14.
 */
public class Launcher {

    private static final int PORT = 6600;         // standard setting for mpd server

    private static final String HOST_PREFIX = "host:";
    private static final String PORT_PREFIX = "port:";

    /**
     * Launcher for the application. First there will be checked whether if there are
     * arguments used for the host and port.
     * The splashscreen is loaded / displayed while the settings are loaded if no
     * main arguments are used and the contact to the server is initialized.
     * @param args
     */
    public static void launchApplication(String[] args) {


         // screen size

        SplashScreen.getSplashScreen();

        Settings settings = initConnection(args);

        Controller controller = new Controller();
        controller.addPlaylist(new Playlist());
        controller.addServerStatus(new ServerStatus());
        controller.addServer(new Server());
        controller.addDirectory(new Directory());

        SplashScreen.close();


    }

    private static Settings initConnection(String[] args) {
        Settings settings;
        if (args != null) {

            String host = null;
            int port = PORT;

            for (String arg : args) {
                if (arg.startsWith(HOST_PREFIX)) {
                    host = arg.substring(HOST_PREFIX.length());
                }
                if (arg.startsWith(PORT_PREFIX)) {
                    port = Integer.parseInt(arg.substring(PORT_PREFIX.length()));
                }
            }
            if (host != null) {
                settings = Settings.getSettings();
                settings.setHost(host);
                settings.setPort(port);

                // add a test for  the settings!

                return settings;
            }
        }
        // if no argument for the host is given!
        try {
            settings = Settings.loadSettings();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }





}
