package com.bono.zero.control;

import com.bono.zero.model.*;
import com.bono.zero.view.ZeroFrame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by hennihardliver on 25/05/14.
 *
 * <p>Title: Controller.java</p>
 */
public class Controller {

    // The current playlist
    Playlist playlist;
    // The server status
    ServerStatus serverStatus;
    // the frame of the interface
    ZeroFrame zeroFrame;
    // the connection class
    Server server;
    // the connection settings
    Settings settings;
    // the directory structure
    Directory directory;

    ServerMonitor serverMonitor;

    public Controller() {}




    //private Command makeCommand(ActionEvent event) {

   // }

    /**
     * Method sendCommand, calls the servers object's
     * sendCommand method and passes an command object
     * as argument.
     * @param command
     */
    private void sendCommand(Command command) {
        try {
            server.sendCommand(command);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addPlaylist(Playlist playlist) {
        this.playlist = playlist;
    }

    public void addServerStatus(ServerStatus serverStatus) {
        this.serverStatus = serverStatus;
    }

    public void addZeroFrame(ZeroFrame zeroFrame) {
        this.zeroFrame = zeroFrame;
    }

    public void addServer(Server server) {
        this.server = server;
    }

    public void addSettings(Settings settings) {
        this.settings = settings;
    }

    public void addDirectory(Directory directory) {
        this.directory = directory;
    }

    public void addServerMonitor(ServerMonitor serverMonitor) {
        this.serverMonitor = serverMonitor;
    }


}
