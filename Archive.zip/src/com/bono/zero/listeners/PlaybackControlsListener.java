package com.bono.zero.listeners;

import com.bono.zero.model.Command;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

/**
 * Created by hennihardliver on 26/05/14.
 */
public class PlaybackControlsListener implements ActionListener {

    HashMap<AbstractButton, Command> buttonCommandHashMap;

    public PlaybackControlsListener() {
        buttonCommandHashMap = new HashMap<AbstractButton, Command>();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
