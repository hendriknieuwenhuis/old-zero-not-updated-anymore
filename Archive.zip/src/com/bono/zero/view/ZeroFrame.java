package com.bono.zero.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;

import com.bono.zero.util.Observer;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableModel;

public class ZeroFrame extends JFrame {
	
	private JPanel mainPanel;
	private PlaylistPanel playlistPanel;
	private DirectoryPanel directoryPanel;
	private PlaybackControls playbackControls;
	
	private Dimension zeroDimension;
	
	public ZeroFrame(Zero zero) {
        super();

		calcDimension();
		setTitle("Zero");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		mainPanel = new JPanel();

		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBorder(new EmptyBorder(5,5,5,5));
		playlistPanel = new PlaylistPanel(zero);
		directoryPanel = new DirectoryPanel(zero);
		playbackControls = new PlaybackControls(zero);
		
		zero.addServerStatusObserver("State", playbackControls);
		zero.addServerStatusObserver("Repeat", playbackControls);
		zero.addServerStatusObserver("Random", playbackControls);
		zero.addPlaylistObserver("Playlist", playlistPanel);
	
		zero.addServerStatusObserver("Song", playlistPanel);

		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, directoryPanel, playlistPanel);
		splitPane.setContinuousLayout(true);
		splitPane.setDividerLocation((zeroDimension.width/3));

		mainPanel.add(splitPane, BorderLayout.CENTER);
		mainPanel.add(playbackControls, BorderLayout.NORTH);
		ZeroMenuBar menuBar = new ZeroMenuBar(zero);
		zero.addServerStatusObserver("Consume", menuBar);
		zero.addServerStatusObserver("Single", menuBar);
		setJMenuBar(menuBar);
		add(mainPanel);

		pack();
		setSize(zeroDimension);
		setVisible(true);
	}
	
	
	
	/*
	 * Method, calculates the dimension to set the 
	 * size of the frame according to the screen size
	 * of the computer the application is run on.
	 */
	private void calcDimension() {
		Rectangle bounds = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
		zeroDimension = bounds.getSize();
	}
	
	
}
