package com.bono.zero.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.ColorModel;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;


import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import com.bono.zero.laf.BonoBorderFactory;
import com.bono.zero.laf.BonoScrollBarUI;
import com.bono.zero.model.Command;
import com.bono.zero.model.Server;
import com.bono.zero.util.Observer;

/**
 * <p>Title: DirectoryPanel.java</p>
 * 
 * <p>Description: This class displays the contents of the 'music'
 * folder that is mounted to the MPDserver as the folder containing
 * the music. The directory structure will be displayed as a JTree.
 * When a file is selected it can be added to the playlist.</p>
 * 
 * @author bono
 *
 */
public class DirectoryPanel extends JPanel {
	
	private final String CUE = "cue";
	
	private Zero zero;
	
	private JTree tree;
	private JScrollPane scrollPane;
	private TreeNode root;
	private TreeSelectionModel selectionModel;
	
	
	public DirectoryPanel(Zero zero) {
		super();
		this.zero = zero;
		setLayout(new BorderLayout());
		
		//UIManager.put("Tree.rendererFillBackground", false);
		
		tree = new JTree(zero.getDirectory().getDirectory());
		tree.addMouseListener(new TreeMouseListener());
		tree.setCellRenderer(new TreeRenderer());
		
		Border threeBorder = BonoBorderFactory.getThreeQuarterBorder(1, Color.RED, 1);
		
		scrollPane = new JScrollPane(tree);
        scrollPane.setBorder(threeBorder);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollPane.getVerticalScrollBar().setUI(new BonoScrollBarUI());
        scrollPane.getHorizontalScrollBar().setUI(new BonoScrollBarUI());



		add(scrollPane, BorderLayout.CENTER);
	}
	
		
	private class TreeMouseListener extends MouseAdapter {
		
		@Override
		public void mouseReleased(MouseEvent e) {
			
			if (e.getClickCount() == 2) {
				TreePath selectedPath = tree.getSelectionPath();
				
				Object[] path = selectedPath.getPath();
				String directoryPath = makePath(path);
				if ((directoryPath.endsWith(CUE)) || (directoryPath.endsWith("m3u"))) {
					System.out.println(directoryPath);
					zero.sendCommand(new Command(Server.LOAD, directoryPath));
					return;
				}
				System.out.println(directoryPath);
				zero.sendCommand(new Command(Server.ADD, directoryPath));
			}
		}
		
		/*
		 * Method makes the path as a String ready
		 * to be send to the server as a parameter,
		 * to add the file or folder to a playlist.
		 */
		private String makePath(Object[] path) {
			String returnPath = "";
			for (int i = 1; i < path.length; i++) {
				if (i == (path.length-1)) {
					returnPath = returnPath + path[i];
					return returnPath;
				} 
				returnPath = returnPath + path[i]+"/";
			}
			return returnPath;
		}	
	}
	
	private class TreeRenderer extends DefaultTreeCellRenderer {
		
		@Override
		public Component getTreeCellRendererComponent(final JTree tree, final Object value, final boolean sel, 
				final boolean expanded, final boolean leaf, final int row, final boolean hasFocus) {
			
			DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
			
			//tree.setBackground(Color.LIGHT_GRAY);
			//renderer.setTextSelectionColor(Color.pink);
			renderer.setBackgroundNonSelectionColor(tree.getBackground());
			renderer.setBackgroundSelectionColor(Color.PINK);
			renderer.setBorderSelectionColor(tree.getBackground());
			return renderer;
		}
	}
	
	
}
