package com.bono.zero.view;

import javax.swing.*;
import java.awt.*;

/**
 * Created by hennihardliver on 23/05/14.
 */
public class SplashScreen extends JDialog {

    private static SplashScreen splashScreen;

    private SplashScreen() {
        super((Frame) null);
        setUndecorated(true);
        JLabel message = new JLabel("Loading application");
        add(message);
        Rectangle bounds = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();

        setSize(200, 200);
        setLocation((bounds.width/2)-(getWidth()/2), (bounds.height/2)-(getHeight()/2));
        setVisible(true);
    }

    public static SplashScreen getSplashScreen() {
        if (splashScreen == null) {
            splashScreen = new SplashScreen();
        }
       return splashScreen;
    }

    public static void close() {
        splashScreen.setVisible(false);
        splashScreen.dispose();
    }
}
