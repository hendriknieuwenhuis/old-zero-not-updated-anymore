package com.bono.zero.view;

import java.awt.*;
import java.io.IOException;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.metal.DefaultMetalTheme;
import javax.swing.plaf.metal.MetalLookAndFeel;

import com.bono.zero.util.Observer;
import com.bono.zero.laf.ZeroTheme;
import com.bono.zero.model.Command;
import com.bono.zero.model.Directory;
import com.bono.zero.model.Initialize;
import com.bono.zero.model.Playlist;
import com.bono.zero.model.Server;
import com.bono.zero.model.ServerMonitor;
import com.bono.zero.model.ServerStatus;
import com.bono.zero.model.Settings;
import com.bono.zero.model.UpdateModel;

public class Zero {
	
	// The current playlist
	Playlist playlist;
	// The server status
	ServerStatus serverStatus;
	// the frame of the interface
	ZeroFrame zeroFrame;
	// the connection class 
	Server server;
	// the connection settings
	Settings settings;
	// the directory structure
	Directory directory;
	
	ServerMonitor serverMonitor;
	
	
	public Zero() {
		//MetalLookAndFeel.setCurrentTheme(new ZeroTheme());
		playlist = new Playlist();
		String[] columns = {"title", "album", "artist"};
		playlist.showColumns(columns);
		serverStatus = new ServerStatus();
		directory = new Directory();
		zeroFrame = new ZeroFrame(this);
		
		Initialize init = new Initialize(this);
		
		//serverMonitor = new ServerMonitor(this, new UpdateModel(this));
		//serverMonitor.start();
		init = null;
		
	}

    public void start() {
        serverMonitor = new ServerMonitor(this, new UpdateModel(this));
        serverMonitor.start();
    }

    public void init() {
        this.init(null);
    }

    public void init(List<String> args) {
        if (args != null) {
            for (String arg : args) {

            }
        }
    }


	
	public void addPlaylistObserver(String key, Observer o) {
		playlist.addObserver(key, o);
	}
	
	public void addServerStatusObserver(String key, Observer o) {
		serverStatus.addObserver(key, o);
	}
	
	public void addDirectoryPanelObserver(String key, Observer o) {
		directory.addObserver(key, o);		
	}
	
	public void sendCommand(Command command) {
		try {
			server.sendCommand(command);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public Playlist getPlaylist() {
		return playlist;
	}
	
	public ServerStatus getServerStatus() {
		return serverStatus;
	}
	
	public Server getServer() {
		return server;
	}
	
	public void setServer(Server server) {
		this.server = server;
	}
	public Settings getSettings() {
		return settings;
	}
	
	public void setSettings(Settings settings) {
		this.settings = settings;
	}
		
	public Directory getDirectory() {
		return directory;
	}
	


}
