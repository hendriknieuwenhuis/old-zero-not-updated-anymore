package com.bono.zero.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.bono.zero.laf.BonoMenuBarUI;
import com.bono.zero.util.Observable;
import com.bono.zero.util.Observer;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;

import com.bono.zero.model.Command;
import com.bono.zero.model.Server;
import com.bono.zero.model.ServerStatus;

public class ZeroMenuBar extends JMenuBar implements Observer {
	
	private final String CONSUME = "consume";
	private final String SINGLE  = "single";
	private JMenu config;
	private JCheckBoxMenuItem consume;
	private JCheckBoxMenuItem single;
	
	private Zero zero;
	
	
	
	public ZeroMenuBar(Zero zero) {
		this.zero = zero;
        //setUI(new BonoMenuBarUI());
		makeBar();
	}
	
	private void makeBar() {
		add(configMenu());
	}
	
	private JMenu configMenu() {
		config = new JMenu("config");
		consume = new JCheckBoxMenuItem("consume");
		consume.setActionCommand(Server.CONSUME);
		consume.addActionListener(new ConfigListener());
		single = new JCheckBoxMenuItem("single");
		single.setActionCommand(Server.SINGLE);
		single.addActionListener(new ConfigListener());
		config.add(consume);
		config.add(single);
		return config;
	}
	
	/*****************************************************
	 *Updates the state of the JCheckBoxMenuItems when an*
	 *update occurs in the ServerStatus.                 *
	 *String update tells the method witch button is to  *
	 *be updated. Although the buttons also update       *
	 *their state when the user interacts with them,     *
	 *to display the MPDserver state the buttons         *
	 *represent, the state must be set from the          *
	 *server finally.                                    *
	 *****************************************************/
	@Override
	public void update(String update, Object arg) {
		if (update.equals(ServerStatus.CONSUME)) {
			String state = (String) arg;
			if (state.equals("0")) {
				consume.setSelected(false);
			} else {
				consume.setSelected(true);
			}
		}else if (update.equals(ServerStatus.SINGLE)) {
			String state = (String) arg;
			if (state.equals("0")) {
				single.setSelected(false);
			} else {
				single.setSelected(true);
			}
		}
			
	}

	
	
	
	private class ConfigListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getActionCommand().equals(Server.CONSUME)) {
				// The command is send after the check box is selected
				// or deselected. The isSelected boolean gives back
				// the select or deselect action just performed.
				// At this point the server is not jet updated so the 
				// consume variable in ServerStatus does not jet
				// correspondent with the button state. After the 
				// ServerStatus is updated this is corrected. 
				if (!consume.isSelected()) {
					zero.sendCommand(new Command(Server.CONSUME, "0"));
				} else {
					zero.sendCommand(new Command(Server.CONSUME, "1"));
				}
			} else if (e.getActionCommand().equals(Server.SINGLE)) {
				if (!single.isSelected()) {
					zero.sendCommand(new Command(Server.SINGLE, "0"));
				} else {
					zero.sendCommand(new Command(Server.SINGLE, "1"));
				}
			}
		}
		
	}

	
}
