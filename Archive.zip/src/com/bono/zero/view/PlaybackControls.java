package com.bono.zero.view;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;

import com.bono.zero.model.Command;
import com.bono.zero.model.Server;
import com.bono.zero.model.ServerStatus;
import com.bono.zero.util.Observer;
import com.bono.zero.laf.BonoIcon;
import com.bono.zero.laf.BonoIconFactory;

/**
 * Observer listens to STATE, RANDOM, REPEAT
 * @author bono
 *
 */
public class PlaybackControls extends ButtonPanel implements Observer {
	
	private final String PP_BUTTON       = "pp";
	//private final String PAUSE_BUTTON    = "pa";
	//private final String PLAY_BUTTON     = "pl";
	private final String STOP_BUTTON     = "st";
	private final String PREV_BUTTON     = "pr";
	private final String NEXT_BUTTON     = "ne";
	//private final String RANDOM_BUTTON   = "ra";
	//private final String REPEAT_BUTTON   = "re";
	
	private final BonoIcon PLAY_ICON     = BonoIconFactory.getPlayButtonIcon();
	private final BonoIcon PAUSE_ICON    = BonoIconFactory.getPauseButtonIcon();
	private final BonoIcon NEXT_ICON     = BonoIconFactory.getNextButtonIcon();
	private final BonoIcon PREVIOUS_ICON = BonoIconFactory.getPreviousButtonIcon();
	private final BonoIcon STOP_ICON     = BonoIconFactory.getStopButtonIcon();
	private final BonoIcon REPEAT_ICON   = BonoIconFactory.getRepeatIcon();
	private final BonoIcon RANDOM_ICON   = BonoIconFactory.getRandomIcon();
	
	private final ControlsHandler HANDLER = new ControlsHandler();
		
	private Zero zero;
	
	public PlaybackControls(Zero zero) {
		super(new FlowLayout(FlowLayout.LEFT));
		this.zero = zero;
			
		addToggleButton(RANDOM_ICON, Server.RANDOM, HANDLER);
		addToggleButton(REPEAT_ICON, Server.REPEAT, HANDLER);
		addSeperator(SwingConstants.VERTICAL);
		addButton(PREVIOUS_ICON, PREV_BUTTON, Server.PREVIOUS, HANDLER);
		addButton(STOP_ICON, STOP_BUTTON, Server.STOP, HANDLER);
		addButton(PLAY_ICON, PP_BUTTON, Server.PLAY, HANDLER);
		addButton(NEXT_ICON, NEXT_BUTTON, Server.NEXT, HANDLER);
	}
	
	
	
	@Override
	public void update(String update, Object arg) {
		String status = (String) arg;
		// update the play / pause button
		if (update.equals(ServerStatus.STATE)) {
			// if playback state is PLAY.
			if (status.equals("play")) {
				((JButton) getButton(PP_BUTTON)).setIcon(PAUSE_ICON);
				((JButton) getButton(PP_BUTTON)).setActionCommand(Server.PAUSE);
			// else playback state is PAUSE or STOP	
			} else {
				((JButton) getButton(PP_BUTTON)).setIcon(PLAY_ICON);
				((JButton) getButton(PP_BUTTON)).setActionCommand(Server.PLAY);
			}
		// update the RANDOM button	
		} else if (update.equals(ServerStatus.RANDOM)) {
			// if RANDOM state is "0" (false)
			if (status.equals("0")) {
				((JToggleButton) getButton(Server.RANDOM)).setSelected(false);
			// else RANDOM state is "1" (true)	
			} else  {
				((JToggleButton) getButton(Server.RANDOM)).setSelected(true);
			}
		// update the REPEAT button	
		} else if (update.equals(ServerStatus.REPEAT)) {
			// if REPEAT state is "0" (false)
			if (status.equals("0")) {
				((JToggleButton) getButton(Server.REPEAT)).setSelected(false);
			// else REPEAT state is "1" (true)	
			} else  {
				((JToggleButton) getButton(Server.REPEAT)).setSelected(true);
			}
		}
	}
	
	
	
	private class ControlsHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if ((e.getActionCommand().equals(Server.REPEAT)) || (e.getActionCommand().equals(Server.RANDOM))) {
				String button = e.getActionCommand();
				if (!((JToggleButton) getButton(button)).isSelected()) {
					zero.sendCommand(new Command(e.getActionCommand(), "0"));
				} else {
					zero.sendCommand(new Command(e.getActionCommand(), "1"));
				}
			} else if (e.getActionCommand().equals(Server.PAUSE)) {
				zero.sendCommand(new Command(e.getActionCommand(), "1"));
			} else {
				zero.sendCommand(new Command(e.getActionCommand()));
			}
			
		}
		
	}


	
}
