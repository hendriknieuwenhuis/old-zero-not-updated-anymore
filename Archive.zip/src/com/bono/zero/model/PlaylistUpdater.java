package com.bono.zero.model;

import java.io.IOException;

import com.bono.zero.view.Zero;

/**
 * <p>Title: PlaylistUpdater.java</p>
 * 
 * <p>Description: This class is an Runnable updater for the
 * Playlist. It is run by the monitor when an update 
 * of the playlist is ordered by a change of the current playlist
 * registered by the monitor. It is run in an other
 * thread than the monitor so the monitor will never be
 * blocked by executing the update of a model.
 * </p>
 * 
 * @author bono
 *
 */
public class PlaylistUpdater implements Runnable {

	/*
	 * Holds the communication object and the
	 * Playlist object needed in this
	 * object.
	 */
	private Zero zero;   
	
	public PlaylistUpdater(Zero zero) {
		this.zero = zero;
	}
	
	@Override
	public void run() {
		/*
		 *  call the server for the current playlist information
		 *  of the server and return it as an array of strings.
		 */
		try {
			zero.getPlaylist().populatePlaylist(zero.getServer().sendCommand(new Command("playlistinfo")));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
