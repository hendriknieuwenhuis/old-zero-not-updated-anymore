package com.bono.zero.model;

/**
 * Class ServerStatusMonitorr creates a worker thread
 * and sets up an idle connection with the MPD Server
 * to monitor to changes in the server.
 */
import java.net.SocketException;
import java.net.Socket;
import java.io.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

import com.bono.zero.model.Command;
import com.bono.zero.model.Settings;
import com.bono.zero.view.Zero;

public class ServerMonitor {
	
	private final String PLAYER   = "changed: player";
	private final String PLAYLIST = "changed: playlist";
	private final String MIXER    = "changed: mixer";
	private final String OPTIONS  = "changed: options";		
	private final byte[] IDLE = "idle\n".getBytes();
	private final byte[] CLEAR_ERROR = "clearerror\n".getBytes();
	private final String OK               = "OK";
	private final String ACK              = "ACK";
	
	private boolean closed;
	
	private boolean waiting;
	private int tries;
	
	private ExecutorService executor;
	private ServerWorker serverWorker;

	private Socket socket;
	private OutputStream writer;
	private BufferedReader reader;
	private InputStreamReader input;
	private String version;
	private String line;
	
	//private StatusUpdater statusUpdater;
	//private PlaylistUpdater playlistUpdater;
	private UpdateModel updateModel;
	//private BlockingQueue<Command> queue;
	private Settings settings;
	private Zero zero;

		
	public ServerMonitor(Zero zero, UpdateModel updateModel) {
		this.zero = zero;
		this.updateModel = updateModel;
		settings = zero.getSettings();
		setupServerMonitor();
	}
	
	public ServerMonitor(Zero zero, BlockingQueue queue) {
		this.settings = zero.getSettings();
		//this.queue = queue;
		setupServerMonitor();
	}

	/*
	 * Method that instantiates the thread pool that
	 * this class uses for monitoring the server and
	 * running for updates when changes occur in the
	 * server. The updates are Runnable objects that
	 * are run in the update() method.
	 */
	private void setupServerMonitor() {
		// instantiate the executors
		executor = Executors.newFixedThreadPool(4);
		// instantiate the runnables.
		serverWorker = new ServerWorker();
		//statusUpdater = new StatusUpdater(zero);
		//playlistUpdater = new PlaylistUpdater(zero);
		
	}
	
	/*
	 * Start method creates the thread for the
	 * worker class to run in.
	 */
	public void start() {
		executor.execute(serverWorker);
		//update(PLAYER);
		//update(PLAYLIST);
	}
	
	// connect to the server.
	private String connect() {
				
		tries = 0;
		
		while (tries <3) {
			try {
				socket = new Socket();
				socket.connect(settings.getAddress());
				socket.setKeepAlive(true);
				input = new InputStreamReader(socket.getInputStream());
				reader = new BufferedReader(input);
				line = reader.readLine();
				if (socket.isConnected()) {
					//closed = false;
					if (line.startsWith(ACK)) {
						writeCommand(CLEAR_ERROR);
						return line;
					} else {
						closed = false;
						//System.out.println(line+" "+closed);
						return line;
					}
				}
				//tries++;
			
			} catch (SocketException s) {
				tries++;
				writer = null;
				System.out.println("socket exception!");
				if (tries == 2) {
					serverWorker.goWait();
				} else {
					try {
						Thread.sleep(10000);
					} catch (InterruptedException i) {
						i.printStackTrace();
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	// write message to the server
	private void writeCommand(byte[] command) {
		if (socket == null) {
			closed = true;
		}
		try {
			if (writer == null) {
				writer = socket.getOutputStream();
			}
			writer.write(command);
			writer.flush();
		} catch (SocketException s) {
			closed = true;
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// reads the servers messages.
	private void listen() {

		String read;

		try {
			if ((input == null) || (reader == null)) {
				input = new InputStreamReader(socket.getInputStream());
				reader = new BufferedReader(input);
			}
			while ((read = reader.readLine()) != null) {
				if (read.startsWith("ACK")) {
					System.out.println(read);
					writeCommand(CLEAR_ERROR);
					closed = true;
					break;
				} else if (read.equals(OK)) {
					break;
				} else {
					updateModel.update(read);
					System.out.println(read);
				}
			}
			
		} catch (SocketException s) {
			closed = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/*
	 * Method that send for an update of the monitored
	 * change in server state. All different kind of
	 * updates are seperate threads so they do not 
	 * block each other when being executed simultaneous.
	 
	private void update(String read) {
		if (read.equals(PLAYLIST)) {
			executor.execute(playlistUpdater);
		} else {
			executor.execute(statusUpdater);
		}
	}*/
	/*
	 * Inner class, the worker class. This class
	 * runs as long as the program runs. It listens
	 * to an idle connection with the server and responds
	 * to its changes.
	 * */
	private class ServerWorker implements Runnable {
		
		private boolean run;

		@Override
		public void run() {
			run = true;
			
			version = connect();
			System.out.println(version);
			
			while (run) {
				if (closed) {
					version = connect();
				}
				
				while (!closed) {
					
					writeCommand(IDLE);

					listen();

					
				}
			}
		}

		public void goWait() {
			waiting = true;
			
			synchronized (this) {
				while(waiting) {
					try {
						wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
