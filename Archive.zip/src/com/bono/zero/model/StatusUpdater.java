package com.bono.zero.model;

import java.io.IOException;

import com.bono.zero.view.Zero;

/**
 * <p>Title: StatusUpdater.java</p>
 * 
 * <p>Description: This class is an Runnable updater for the
 * ServerStatus. It is run by the monitor when an update 
 * of the status is ordered by a change of the servers status
 * registered by the monitor. It is a Runnable in an other
 * thread than the monitor so the monitor will never be
 * blocked by executing the update of a model.
 * </p>
 * 
 * @author bono
 *
 */
public class StatusUpdater implements Runnable {

	/*
	 * Holds the communication object and the
	 * serverstatus object needed in this
	 * object.
	 */
	private Zero zero;   
	
	
	public StatusUpdater(Zero zero) {
		this.zero = zero;
	}
	
	@Override
	public void run() {
		/*
		 *  call the server for the current status information
		 *  of the server and rupdate the serverstatus object.
		 */
		try {
			zero.getServerStatus().setStatus(zero.getServer().sendCommand(new Command("status")));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
