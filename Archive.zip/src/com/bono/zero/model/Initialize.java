package com.bono.zero.model;

import java.io.IOException;

import com.bono.zero.view.SettingsDialog;
import com.bono.zero.view.Zero;

/**
 * <p>Title: Initialize.java</p>
 * 
 * <p>Description: This class initializes zero. It sets/loads the
 * settings for the connection with the MPDserver.  After a successful
 * connection is established an  
 * @author bono
 *
 */
public class Initialize {
	
	private Settings settings;
	private Server server;
	private Zero zero;
	
	boolean wait;
	
	public Initialize(Zero zero) {
		this.zero = zero;
		server = new Server();
		init();
	}

	private void init() {
		System.out.println("1");
		try {
			System.out.println("2");
			settings = Settings.loadSettings();
		} catch (ClassNotFoundException c) {
			c.printStackTrace();
		} catch (IOException e) {
			newSettings();
		}
		testSettings();
		zero.setServer(server);
		zero.setSettings(settings);
	}
	
	private void newSettings() {
		System.out.println("3");
		if (settings == null) {
			settings = Settings.getSettings();
		}
		new SettingsDialog(settings, this);
		wait = true;
		while (wait) {
			synchronized (this) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		testSettings();
	}
	
	private void testSettings() {
		server.setAddress(settings.getAddress());
		//if (!communicate.ping()) {
		//	newSettings();
			//return;
		//}
		saveSettings();
	}
	
	private void saveSettings() {
		try {
			settings.saveSettings();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Settings getSettings() {
		return settings;
	}
	
	//public Communicate getCommunicate() {
	///	return communicate;
	//}
	
	public void stopWaiting() {
		synchronized (this) {
			wait = false;
			notify();
		}
	}
}
