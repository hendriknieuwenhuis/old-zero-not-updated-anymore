package com.bono.zero.model;

import com.bono.zero.view.Zero;


/**
 * <p>Title: DirectoryUpdater.java</p>
 * 
 * <p>Description: This class is an Runnable updater for the
 * Directory. It is run by the monitor when an update 
 * of the directory is ordered by a change of the servers directory
 * registered by the monitor. It is a Runnable in an other
 * thread than the monitor so the monitor will never be
 * blocked by executing the update of a model.
 * </p>
 * 
 * @author bono
 *
 */
public class DirectoryUpdater implements Runnable {

	/*
	 * Holds the communication object and the
	 * serverstatus object needed in this
	 * object.
	 */
	private Zero zero; 
	
	public DirectoryUpdater(Zero zero) {
		this.zero =zero;
	}

	@Override
	public void run() {
		
		/*
		 *  call the server for the current directory structure
		 *  of the server, update the directory object and invoke
		 *  doNotify().
		 */
		try {
			zero.getDirectory().setDirectory(zero.getServer().sendCommand(new Command("listall")));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
