package com.bono.zero.model;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.bono.zero.view.Zero;

/**
 * <p>Title: UpdateModel.java</p>
 * 
 * <p>Description: This class runs the Runnable updaters
 * to update the models. When the server is changed the monitor 
 * will notice and sends this class the proper update request.</p> 
 * 
 * @author bono
 *
 */
public class UpdateModel {
	
	private final String PLAYER   = "changed: player";
	private final String PLAYLIST = "changed: playlist";
	private final String MIXER    = "changed: mixer";
	private final String OPTIONS  = "changed: options";
	private final String DATABASE = "changed: database";
	
	private StatusUpdater statusUpdater;
	private PlaylistUpdater playlistUpdater;
	 
	
	private ExecutorService executor;
	
	private Zero zero;
	
	public UpdateModel(Zero zero) {
		this.zero = zero;
		init();
	}
	
	private void init() {
		// make the thread pool
		executor = Executors.newFixedThreadPool(10);
		// instantiate the updaters
		statusUpdater = new StatusUpdater(zero);
		playlistUpdater = new PlaylistUpdater(zero);
		// initialize model
		executor.execute(statusUpdater);
		executor.execute(playlistUpdater);
		executor.execute(new DirectoryUpdater(zero));
	}
	/*
	 * Method that sends for an update of the monitored
	 * change in server state. All different kind of
	 * updates are seperate threads so they do not 
	 * block each other when being executed simultaneous.
	 */
	public void update(String read) {
		if (read.equals(PLAYLIST)) {
			executor.execute(playlistUpdater);
			executor.execute(statusUpdater);
		} else if (read.equals(DATABASE)) {
			executor.execute(new DirectoryUpdater(zero));
		} else {
			executor.execute(statusUpdater);
		}
	}
}
